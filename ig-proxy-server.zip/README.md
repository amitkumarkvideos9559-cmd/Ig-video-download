# Instagram Proxy Server

## 🚀 Deploy on Render
1. Go to [Render.com](https://render.com)
2. Sign up (with GitHub or Google)
3. Create **New Web Service**
4. Choose **Deploy from ZIP**
5. Upload this ZIP file
6. Deploy → Get your proxy URL (example: `https://your-proxy.onrender.com`)

## 🔹 Usage in Blogger
In your Blogger JavaScript:
```js
const proxy = "https://your-proxy.onrender.com/api";
```

Now, when you call:
```
fetch(proxy + "?url=" + encodeURIComponent(instaUrl))
```
It will return Instagram page HTML safely.
